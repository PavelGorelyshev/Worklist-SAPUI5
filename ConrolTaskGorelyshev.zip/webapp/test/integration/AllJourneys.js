/*global QUnit*/

jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"jetCourses/ConrolTaskGorelyshev/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"jetCourses/ConrolTaskGorelyshev/test/integration/pages/Worklist",
	"jetCourses/ConrolTaskGorelyshev/test/integration/pages/Object",
	"jetCourses/ConrolTaskGorelyshev/test/integration/pages/NotFound",
	"jetCourses/ConrolTaskGorelyshev/test/integration/pages/Browser",
	"jetCourses/ConrolTaskGorelyshev/test/integration/pages/App"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "jetCourses.ConrolTaskGorelyshev.view."
	});

	sap.ui.require([
		"jetCourses/ConrolTaskGorelyshev/test/integration/WorklistJourney",
		"jetCourses/ConrolTaskGorelyshev/test/integration/ObjectJourney",
		"jetCourses/ConrolTaskGorelyshev/test/integration/NavigationJourney",
		"jetCourses/ConrolTaskGorelyshev/test/integration/NotFoundJourney"
	], function () {
		QUnit.start();
	});
});